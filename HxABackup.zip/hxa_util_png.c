#define _CRT_SECURE_NO_WARNINGS
#include <string.h>
#include <stdlib.h>
#include <stdio.h>
#include "hxa.h"
#include "hxa_utils.h"

#define FALSE 0
#define TRUE !FALSE

typedef enum{
	HXA_PNG_CT_GRAYSCALE = 0,
	HXA_PNG_CT_RGB = 2,
	HXA_PNG_CT_INDEXED = 3,
	HXA_PNG_CT_GRAYSCALE_AND_ALPHA = 4,
	HXA_PNG_CT_RGB_AND_ALPHA = 6
}HxAPNGChannelTypes;

#define MOD_ADLER 65521;

extern unsigned char *hxa_util_file_load(char *file_name, size_t *size);

void hxa_png_adler32_compute(unsigned char *output, unsigned char *data,  unsigned int channels, unsigned int x, unsigned int y) 
{
	unsigned int a = 1, b = 0;
	size_t i, j, pixel = 0;
	x *= channels;
	for(i = 0; i < y; i++)
	{
		b = (b + a) % MOD_ADLER;
		for(j = 0; j < x; j++)
		{
			a = (a + data[pixel++]) % MOD_ADLER;
			b = (b + a) % MOD_ADLER;
		}
	}    
	a = (b << 16) | a;
	output[0] = (a >> 24) & 0xFF;
	output[1] = (a >> 16) & 0xFF;
	output[2] = (a >> 8) & 0xFF;
	output[3] = a & 0xFF;
}

void  hxa_png_adler32_compute_verify(unsigned char *output, unsigned char *data, size_t length) 
{
	unsigned int a = 1, b = 0;
	size_t i;
	for(i = 0; i < length; ++i)
	{
		a = (a + data[i]) % MOD_ADLER;
		b = (b + a) % MOD_ADLER;
	}    
	a = (b << 16) | a;
	output[0] = (a >> 24) & 0xFF;
	output[1] = (a >> 16) & 0xFF;
	output[2] = (a >> 8) & 0xFF;
	output[3] = a & 0xFF;
}

/* Table of CRCs of all 8-bit messages. */
unsigned long crc_table[256];
   
/* Flag: has the table been computed? Initially false. */
int crc_table_computed = 0;
   
/* Make the table for a fast CRC. */
void hxa_png_crc_compute_table(void)
{
	unsigned long c;
	int n, k;
   
	for(n = 0; n < 256; n++)
	{
		c = (unsigned long)n;
		for(k = 0; k < 8; k++)
		{
			if(c & 1)
				c = 0xedb88320L ^ (c >> 1);
			else
				c = c >> 1;
		}
		crc_table[n] = c;
	}
	crc_table_computed = 1;
}

void hxa_png_crc_compute(unsigned char *output, unsigned char *read_buffer, int length)
{
	unsigned int crc = 0xffffffffL, i, tmp;
 	if(!crc_table_computed)
		hxa_png_crc_compute_table();
	for(i = 0; i < length; i++)
	{
		crc = crc_table[(crc ^ read_buffer[i]) & 0xff] ^ (crc >> 8);	
	}
	crc =  crc ^ 0xffffffffL;
	output[0] = (crc >> 24) & 0xFF;
	output[1] = (crc >> 16) & 0xFF;
	output[2] = (crc >> 8) & 0xFF;
	output[3] = crc & 0xFF;
}


   unsigned long update_crc(unsigned long crc, unsigned char *buf,
                            int len)
   {
     unsigned long c = crc;
     int n;
   
     if (!crc_table_computed)
       hxa_png_crc_compute_table();
     for (n = 0; n < len; n++) {
       c = crc_table[(c ^ buf[n]) & 0xff] ^ (c >> 8);
     }
     return c;
   }
   
   /* Return the CRC of the bytes buf[0..len-1]. */
   unsigned long crc(unsigned char *buf, int len)
   {
     return update_crc(0xffffffffL, buf, len) ^ 0xffffffffL;
   }


extern int hxa_inflate(unsigned char *output, size_t *output_length, unsigned char *input, size_t input_length);


void hxa_load_unpack_uint8(unsigned char *input_buffer, unsigned char *output_buffer, unsigned int x, unsigned int y, unsigned int channels)
{
	unsigned int i, j, k, read = 0, write = 0, acces_a, acces_b, acces_c;
	int a, c, b, p, pa, pb, pc;
	unsigned char tmp[4];
	if(input_buffer[read] == 2)
		input_buffer[read] = 0;
	else if(input_buffer[read] == 2)
		input_buffer[read] = 5;
	for(i = 0; i < y; i++)
	{
		switch(input_buffer[read++])
		{
			case 0 :
				memcpy(&output_buffer[write], &input_buffer[read], x * channels);
				write += channels * x;
				read += channels * x;
			break;
			case 1 :
				acces_a = write;
				for(j = 0; j < channels; j++)
					output_buffer[write++] = input_buffer[read++];
				for(; j < x * channels; j++)
					output_buffer[write++] = input_buffer[read++] + output_buffer[acces_a++];				
			break;
			case 2 :
				acces_b = write - x * channels;
				for(j = 0; j < x * channels; j++)
					output_buffer[write++] = input_buffer[read++] + output_buffer[acces_b++];
			break;
			case 3 :
				acces_a = write;
				acces_b = write - x * channels;
				for(j = 0; j < channels; j++)
					output_buffer[write++] = input_buffer[read++] + output_buffer[acces_b++] / 2;
				for(; j < x * channels; j++)
					output_buffer[write++] = (unsigned int)input_buffer[read++] + ((unsigned int)output_buffer[acces_a++] + (unsigned int)output_buffer[acces_b++]) / 2;	

			break;
			case 4 :
				acces_a = write;
				acces_b = acces_c = write - x * channels;
				for(j = 0; j < channels; j++)
					output_buffer[write++] = input_buffer[read++] + output_buffer[acces_b++];
				for(j = channels; j < x * channels; j++)
				{
					a = b = c = 0;
					for(k = 0; k < 1; k++)
					{
						a += output_buffer[acces_a + k];
						b += output_buffer[acces_b + k];
						c += output_buffer[acces_c + k];
					}
					p = a + b - c;
					if(p > a)
						pa = p - a;
					else
						pa = a - p;
					if(p > b)
						pb = p - b;
					else
						pb = b - p;
					if(p > c)
						pc = p - c;
					else
						pc = c - p;
					if(pa <= pb)
					{
						if(pa <= pc)
						{
							for(k = 0; k < 1; k++)
								output_buffer[write++] = input_buffer[read++] + output_buffer[acces_a + k];	
						}else
						{
							for(k = 0; k < 1; k++)
								output_buffer[write++] = input_buffer[read++] + output_buffer[acces_c + k];	
						}
					}else
					{
						if(pb <= pc)
						{
							for(k = 0; k < 1; k++)
								output_buffer[write++] = input_buffer[read++] + output_buffer[acces_b + k];	
						}else
						{
							for(k = 0; k < 1; k++)
								output_buffer[write++] = input_buffer[read++] + output_buffer[acces_c + k];	
						}
					}
					acces_a += 1;
					acces_b += 1;
					acces_c += 1;
				}
			break;			
			case 5 : /* First line version on read abrage of A and b */
				acces_a = write;
				acces_b = write - x * channels;
				for(j = 0; j < channels; j++)
					output_buffer[write++] = input_buffer[read++];
				for(; j < x * channels; j++)
					output_buffer[write++] = input_buffer[read++] + output_buffer[acces_a++] / 2;	
			break;
			case 6 :
				acces_a = write;
				acces_b = write - x * channels;
				for(j = 0; j < channels; j++)
					output_buffer[write++] = input_buffer[read++] + output_buffer[acces_b++] / 2;
				for(; j < x * channels; j++)
					output_buffer[write++] = input_buffer[read++] + (output_buffer[acces_a++] + output_buffer[acces_b++]) / 2;	
			break;
		}
	}
}

int hxa_load_png(HXAFile *file, char *file_name)
{
	char *name = "color";
	unsigned int channels[] = {1, 0, 3, 3, 2, 0, 4};
	unsigned int x, y, i, j, meta_data_used = 0, packed_size = 0;
	unsigned char bits, compression, filter, interlace, *meta_data;
	HxAPNGChannelTypes color;
	HXANode *node;
	union {char text[5]; unsigned int type;}type;
	size_t size, pos, chunk_length, bitmap_size;
	unsigned char *data, *unprocessed_data, *image_data;
	data = hxa_util_file_load(file_name, &size);
	type.text[4] = 0;
	chunk_length = data[11] + data[10] * 256 + data[9] * 256 * 256 + data[8] * 256 * 256 * 256;
	x = data[19] + data[18] * 256 + data[17] * 256 * 256 + data[16] * 256 * 256 * 256;
	y = data[23] + data[22] * 256 + data[21] * 256 * 256 + data[20] * 256 * 256 * 256;
	bits = data[24];
	color = data[25];
	compression = data[26]; // Must be 0 Deflate
	if(compression != 0)
	{
		printf("HxA Error: PNG loader does only support the standard compression format.\n");
		return FALSE;
	}
	filter = data[27]; // Must be 0
	if(filter != 0)
	{
		printf("HxA Error: PNG loader does only support the standard filter format.\n");
		return FALSE;
	}
	interlace = data[28]; // 0, regular 1 adam7 8 * 8
	if(interlace != 0)
	{
		printf("HxA Error: PNG loader does not support Adam7 interlace yet.\n");
		return FALSE;
	}
	meta_data = malloc(size);
	bitmap_size = x * y * channels[color] * bits / 8;
	unprocessed_data = malloc(bitmap_size + y);
	for(pos = 8 + 8 + chunk_length + 4; pos < size; pos += chunk_length + 12)
	{
		chunk_length = data[pos + 3] + data[pos + 2] * 256 + data[pos + 1] * 256 * 256 + data[pos] * 256 * 256 * 256;
		memcpy(&type.type, &data[pos + 4], 4);
		if(type.type == 1413563465)
		{
			for(i = 0; i < chunk_length; i++)
				data[packed_size++] = data[pos + 8 + i];
/*			hxa_inflate(image_data, bitmap_size, &i, data, chunk_length);
			f_print_raw(data, size);
			exit(0);*/
		}else
		{
			memcpy(&meta_data[meta_data_used], &data[pos], chunk_length + 12);
			meta_data_used += chunk_length + 12;
		}
	}
	meta_data = realloc(meta_data, meta_data_used);
	hxa_inflate(unprocessed_data, &bitmap_size, &data[2], packed_size - 2 - 4);
	{
		unsigned char checksum[4], checksum2[4];
		hxa_png_adler32_compute_verify(checksum, unprocessed_data, x * y * channels[color] + y);
		checksum2[0] = data[packed_size + 0 - 4];
		checksum2[1] = data[packed_size + 1 - 4];
		checksum2[2] = data[packed_size + 2 - 4];
		checksum2[3] = data[packed_size + 3 - 4];
		packed_size++;
	}


	image_data = malloc(x * y * channels[color]);
	hxa_load_unpack_uint8(unprocessed_data, image_data, x, y, channels[color]);

	free(data);
	file->node_count++;
	file->node_array = realloc(file->node_array, (sizeof *file->node_array) * file->node_count);
	node = &file->node_array[file->node_count - 1];
	node->type = HXA_NT_IMAGE;
	node->content.image.type = HXA_IT_2D_IMAGE;
	node->content.image.resolution[0] = x;
	node->content.image.resolution[1] = y;
	node->content.image.resolution[2] = 1;
	node->content.image.image_stack.layer_count = 1;
	node->content.image.image_stack.layers = malloc(sizeof *node->content.image.image_stack.layers);
	node->content.image.image_stack.layers->components = channels[color];
	node->content.image.image_stack.layers->type = HXA_LDT_UINT8;
	node->content.image.image_stack.layers->data.uint8_data = image_data;
	for(i = 0; name[i] != 0; i++)
		node->content.image.image_stack.layers->name[i] = name[i];
	node->content.image.image_stack.layers->name[i] = 0;
	node->meta_data_count = 2;
	node->meta_data = malloc((sizeof *node->meta_data) * 2);
	name = "name";
	for(i = 0; name[i] != 0; i++)
		node->meta_data[0].name[i] = name[i];
	node->meta_data[0].name[i] = 0;
	node->meta_data[0].type = HXA_MDT_TEXT;	
	for(i = 0; file_name[i] != 0; i++);
	node->meta_data[0].value.text_value = malloc(i + 1);
	for(; i != 0 && file_name[i] != '/' && file_name[i] != '\\'; i--);
	if(file_name[i] == '/' || file_name[i] == '\\')
		i++;
	for(j = 0; file_name[i + j] != 0 && file_name[i + j] != '.'; j++)
		node->meta_data[0].value.text_value[j] = file_name[i + j];
	node->meta_data[0].value.text_value[j] = 0;
	node->meta_data[0].array_length = j;
	name = "png_cunks";
	for(i = 0; name[i] != 0; i++)
		node->meta_data[1].name[i] = name[i];
	node->meta_data[1].name[i] = 0;
	node->meta_data[1].type = HXA_MDT_BINARY;
	node->meta_data[1].array_length = meta_data_used;
	node->meta_data[1].value.bin_value = meta_data;
	return TRUE;
}



/*

*/


int hxa_util_buffer_save_png(unsigned char *pixels, unsigned int channels, unsigned int stride, unsigned int x, unsigned int y, char *file_name, unsigned char *additional_chuncks, unsigned int additional_chunk_length)
{
	FILE *file;
	unsigned int i, j, pixel_length, data_length, file_length, compression_left, write_pos, row_pos;
	unsigned short s;
	char *data, channel_code[] = {0, 0, 4, 2, 6};
	unsigned char footer[] = {0, 0, 0, 0, 73, 69, 78, 68, 174, 66, 96, 130};
	unsigned char header[] = {137,
			'P',
			'N',
			'G',
			13,
			10,
			26,
			10,
			0, /* Chunk length */
			0,
			0,
			13,
			'I',
			'H',
			'D',
			'R',
			0, /* size X */
			0,
			0,
			0,
			0, /* size y */
			0,
			0,
			40,
			8, /* bits */
			2, /* Color */
			0, /* Compression */
			0, /* Filter */
			0,
			0, /* CRC */
			0,
			0,
			0,
			0, /* Chunk length */
			0,
			0,
			0,
			'I', /*Chunk type*/
			'D',
			'A',
			'T'}; /* Interlace (0 == None)*/
	
	file = fopen(file_name, "wb");
	if(file == NULL)
		return FALSE;
	pixel_length = (x * channels + 1) * y;
	data_length = pixel_length + (1 + pixel_length / 0xFFFF) * 5 + 2 + 4;
	file_length = sizeof(header) + data_length + 4 + 12 + additional_chunk_length;
	data = malloc(file_length);
	memcpy(data, header, sizeof(header));
	data[16] = (x >> 24) & 0xFF;
	data[17] = (x >> 16) & 0xFF;
	data[18] = (x >> 8) & 0xFF;
	data[19] = x & 0xFF;
	data[20] = (y >> 24) & 0xFF;
	data[21] = (y >> 16) & 0xFF;
	data[22] = (y >> 8) & 0xFF;
	data[23] = y & 0xFF;
	data[25] = channel_code[channels];
//	hxa_png_crc_compute(checksum, &data[i], 29 - 12);
	hxa_png_crc_compute(&data[17 + 12], &data[12], 13 + 4);
	data[33] = (data_length >> 24) & 0xFF;
	data[34] = (data_length >> 16) & 0xFF;
	data[35] = (data_length >> 8) & 0xFF;
	data[36] = data_length & 0xFF;
	write_pos = sizeof(header);
	row_pos = x * channels;
	data[write_pos++] = 120; /* uncompressed */				
	data[write_pos++] = 218; /* uncompressed */
	for(i = compression_left = 0; i < y;)
	{
		if(compression_left == 0)
		{
			if(pixel_length > 0xFFFF)
			{
				data[write_pos++] = 0; /* uncompressed */
				data[write_pos++] = 0xFF; /* length */
				data[write_pos++] = 0xFF; 
				data[write_pos++] = 0; /* inv legth */
				data[write_pos++] = 0;
				compression_left = 0xFFFF;
			}else
			{
				s = pixel_length;
				data[write_pos++] = 1; /* Last uncompressed uncompressed */
				data[write_pos++] =  s & 0xFF;
				data[write_pos++] = (s >> 8) & 0xFF; /* length */
				s = ~s;
				data[write_pos++] = s & 0xFF;
				data[write_pos++] = (s >> 8) & 0xFF; /* inv legth */
				compression_left = 0xFFFF;
			}
		}
		if(row_pos == x * channels)
		{
			data[write_pos++] = 0;
			compression_left--;
			pixel_length--;
			row_pos = 0;
		}else
		{
			if(compression_left >= x * channels - row_pos)
			{
				if(channels == stride)
					memcpy(&data[write_pos], &pixels[i * x * channels + row_pos], x * channels - row_pos);
				else
					for(j = 0; j < x * channels - row_pos; j++)
						data[write_pos + j] = pixels[i * x * stride + ((row_pos + j) / channels) * stride + (row_pos + j) % channels];
				write_pos += x * channels - row_pos;
				compression_left -= x * channels - row_pos;				
				pixel_length -= x * channels - row_pos;
				row_pos = x * channels;
				i++;
			}else
			{				
				if(channels == stride)
					memcpy(&data[write_pos], &pixels[i * x * channels + row_pos], compression_left);
				else
					for(j = 0; j < compression_left; j++)
						data[write_pos + j] = pixels[i * x * stride + ((row_pos + j) / channels) * stride + (row_pos + j) % channels];
				write_pos += compression_left;
				row_pos += compression_left;	
				pixel_length -= compression_left;
				compression_left = 0;
			}
		}
	}
	hxa_png_adler32_compute(&data[write_pos], pixels, channels, x, y);
	write_pos += 4;
	hxa_png_crc_compute(&data[write_pos], &data[37], write_pos - 37);
	write_pos += 4;
	if(additional_chuncks != NULL && additional_chunk_length != 0)
	{
		memcpy(&data[write_pos], additional_chuncks, additional_chunk_length);
		write_pos += additional_chunk_length;
	}
	memcpy(&data[write_pos], footer, 12);
	fwrite(data, 1, file_length, file);
	fclose(file);
	free(data);
	return TRUE;
}


void hxa_util_node_save_png(HXANode *node, char *name)
{
	unsigned int i, j, k, length, slice_count, channel_end;
	char *slice, *cube_slizes[6] = {"_pos_x", "_neg_x", "_pos_y", "_neg_y", "_pos_z", "_neg_z"}, slice_buffer[256], file_name[1024];
	unsigned char *data, *additional_chuncks;
	unsigned char additional_chunk_length;
	slice_count = 1;

	additional_chuncks = hxa_util_meta_get(node->meta_data, node->meta_data_count, "png_cunks", HXA_MDT_BINARY, &additional_chunk_length, FALSE);
	if((node->content.image.type == HXA_IT_1D_IMAGE || node->content.image.type == HXA_IT_2D_IMAGE) && 
		node->content.image.image_stack.layer_count == 1 && 
		node->content.image.image_stack.layers[0].components <= 4)
	{
		sprintf(file_name, "%s.png", name);
		data = node->content.image.image_stack.layers[0].data.uint8_data;
		if(node->content.image.image_stack.layers[0].type == HXA_LDT_UINT8)
			hxa_util_buffer_save_png(data, 
								node->content.image.image_stack.layers[0].components, 
								node->content.image.image_stack.layers[0].components, 
								node->content.image.resolution[0], 
								node->content.image.resolution[1], 
								file_name,
								additional_chuncks, 
								additional_chunk_length);
	}

	if(node->content.image.type == HXA_IT_CUBE_IMAGE)
		slice_count = 6;
	else if(node->content.image.type == HXA_IT_3D_IMAGE)
		slice_count = node->content.image.resolution[2];
	for(i = 0; i < node->content.image.image_stack.layer_count; i++)
	{
		if(node->content.image.image_stack.layers[i].type == HXA_LDT_UINT8)
		{
			data = node->content.image.image_stack.layers[i].data.uint8_data;
			for(j = 0; j < slice_count; j++)
			{
				slice = "";
				if(node->content.image.type == HXA_IT_CUBE_IMAGE)
					slice = cube_slizes[j];
				else if(node->content.image.type == HXA_IT_3D_IMAGE)
				{
					sprintf(slice_buffer, "_slice_%u", j);
					slice = slice_buffer;
				}

				if(node->content.image.image_stack.layers[i].components <= 4)
				{
					sprintf(file_name, "%s_%s%s.png", name, node->content.image.image_stack.layers[i].name, slice);
					hxa_util_buffer_save_png(&data[node->content.image.resolution[0] * node->content.image.resolution[1] * node->content.image.image_stack.layers[i].components * j], 
							node->content.image.image_stack.layers[i].components, 
							node->content.image.image_stack.layers[i].components, 
							node->content.image.resolution[0], 
							node->content.image.resolution[1], 
							file_name,
							additional_chuncks, 
							additional_chunk_length);
				}else
				{
					for(k = 0; k < node->content.image.image_stack.layers[i].components; k += 4)
					{
						channel_end = k + 4;
						if(channel_end < node->content.image.image_stack.layers[i].components)
							channel_end = node->content.image.image_stack.layers[i].components;
						if(channel_end == k + 1)
							sprintf(file_name, "%s_%s%s_channel_%u.png", name, node->content.image.image_stack.layers[i].name, slice, channel_end);
						else
							sprintf(file_name, "%s_%s%s_channel_%u_to_%u.png", name, node->content.image.image_stack.layers[i].name, slice, k + 1, channel_end);
						hxa_util_buffer_save_png(&data[node->content.image.resolution[0] * node->content.image.resolution[1] * node->content.image.image_stack.layers[i].components * j + k], 
							channel_end - k, 
							node->content.image.image_stack.layers[i].components, 
							node->content.image.resolution[0], 
							node->content.image.resolution[1], 
							file_name,
							additional_chuncks, 
							additional_chunk_length);
					}
				}
			}
		}			
	}
}


void hxa_util_file_save_png(HXAFile *file, char *path)
{
	unsigned int i, j, k, length;
	char *name, file_name[1024];
	for(i = 0; i < file->node_count; i++)
	{
		if(file->node_array[i].type == HXA_NT_IMAGE)
		{
			name = hxa_util_meta_get(file->node_array[i].meta_data, file->node_array[i].meta_data_count, HXA_CONVENTION_SOFT_NAME, HXA_MDT_TEXT, &length, FALSE);
			if(name == NULL)
				sprintf(file_name, "%snode_%u", path, i);
			else
				sprintf(file_name, "%s%s", path, name);
			hxa_util_node_save_png(&file->node_array[i], file_name);
		}
	}
}